package Map;

import java.util.LinkedHashMap;

public class LinkedHashMapp {
	
	//Order will be preserved it display as it is but not in Hashmap

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedHashMap<Object,Integer> lhm = new LinkedHashMap<Object,Integer>();
		
		lhm.put("One", 1);
		lhm.put(3, 2);
		lhm.put("Three", 3);
		
		
		System.out.println(lhm);
		
		System.out.println(lhm.get("Three"));
		
		//remove,replace can also be used
		
		

	}

}
