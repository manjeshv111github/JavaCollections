package Map;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Hashmapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		
		map.put(1, "One");
		map.put(2, "Two");
		map.put(3, "Three");
		map.put(4, "Four");
		map.put(5, "Six");

		System.out.println(map);//displays all the key and values
		
		String str = map.get(2);
		System.out.println(str);//getting the values
		
		System.out.println(map.keySet());// shows all the keys present in the map
		
		System.out.println(map.values());//all values present in the map
		
		System.out.println(map.replace(5, "Five"));//replacing the values
		
		System.out.println(map.get(5));
		
		System.out.println(map);
		
		
		
		
		
		
		
	}

}
