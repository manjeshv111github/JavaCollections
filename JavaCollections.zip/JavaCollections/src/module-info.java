/**
 * 
 */
/**
 * 
 */
module JavaCollections {
}