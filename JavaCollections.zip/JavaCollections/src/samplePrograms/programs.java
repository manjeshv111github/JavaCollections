package samplePrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

public class programs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Find the Min And max value in a given integer array
		
		int i[]= {22,133,43,55,767};
		
		ArrayList<Integer> in = new ArrayList<Integer>();
		
		for(int j=0;j<i.length;j++) {
			
			in.add(i[j]);
		}
		
		System.out.println(in);
		
		//Min value
		System.out.println(Collections.min(in));
		
		//Max value
		System.out.println(Collections.max(in));
		
		//Display in acceding order
		Collections.sort(in); 
		
		System.out.println(in);
		
		//Reverse Order
		Collections.sort(in,Collections.reverseOrder());
		
		System.out.println(in);
		
		//remove duplicates in a string
		
		String str1 = "MyLaptop is thinkpad yes";	
		
		//creating linkedhashset bcs it stores only unique values
		//using character data type bcs we are adding each charector to linkedhashset
		LinkedHashSet<Character> lhs = new LinkedHashSet<Character>();
		
		for(int t=0;t<str1.length();t++) {
			lhs.add(str1.charAt(t));
		}

		for(char as:lhs) {
			System.out.print(as);
		}
		
		System.out.println();
		
		//remove duplicates in a Integer
		
		int ie=234366754;
		//converting int to string bcs we cannot directly add each char 
		String str3 = Integer.toString(ie);
		
		LinkedHashSet<Character> lhs2 = new LinkedHashSet<Character>();
		
		for(int k=0;k<str3.length();k++){
			
			lhs2.add(str3.charAt(k));
			
		}
		
		for(char cht:lhs2) {
			System.out.print(cht);
		}
		
		System.out.println();
		
		//fetching values from Set interface
		
		LinkedHashSet<String> lhs3 = new LinkedHashSet<String>();
		
		lhs3.add("String1");
		lhs3.add("String2");
		lhs3.add("String3");
		lhs3.add("String4");
		
		//since we are not directly take values from set interface we have to convert them into String array or else use for each loop
		
		String[] strg = lhs3.toArray(new String[0]);
		
		String stgr = strg[1];
		
		System.out.println(stgr);
		
		//counting number of times duplicate values present
		
		ArrayList<Integer> aar1 = new ArrayList<Integer>();
		
		aar1.add(1);
		aar1.add(1);
		aar1.add(2);
		aar1.add(3);
		
		System.out.println(Collections.frequency(aar1, 1));
		
		//Simple way to convert array into list
		
		String countryArray[]
	            = { "India", "Pakistan", "Afganistan",
	                "Srilanka" };
	       
	        System.out.println("Array input: "
	                           + Arrays.toString(countryArray));
	 
	        List<String> countryList = Arrays.asList(countryArray);
	        System.out.println("Converted elements: "
	                           + countryList);
	        
	        //Java Program to Remove a Specific Element From a Collection
	        
	        
	        LinkedHashSet<String> lhs4 = new LinkedHashSet<String>();
	        
	        lhs4.add("abc");
	        lhs4.add("def");
	        lhs4.add("ghi");
	        
	        lhs4.remove("ghi");
	        
	        System.out.println(lhs4);
	        
	        //reverse method comes in list interface inly
	        
	        List<Integer> inh = new ArrayList<Integer>();
	        inh.add(1);
	        inh.add(2);
	        inh.add(3);
	        
	       Collections.reverse(inh);
	       
	       System.out.println(inh);
	        
	        
	        
		
		
		
		
		

	
	}

}
