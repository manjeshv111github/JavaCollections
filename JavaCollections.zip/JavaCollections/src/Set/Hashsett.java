package Set;

import java.util.HashSet;

public class Hashsett {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hs = new HashSet<String>();
		
		hs.add("String1");
		hs.add("6");
		hs.add("true");
		hs.add("6");//duplicate values are not allowed 
		System.out.println(hs);
		System.out.println(hs.size());
		
		HashSet<String> hs2 = new HashSet<String>();
		hs2.add("String2");
		hs2.add("5");
		hs2.add("false");
		
		System.out.println(hs2);
		
		System.out.println(hs.retainAll(hs2));
		
		//converting hashset to array to retrive the data
		
		
		HashSet<String> hs3 = new HashSet<String>();
		
		hs3.add("One");
		hs3.add("Two");
		hs3.add("Three");
		
		String[] str = hs3.toArray(new String[0]);
		
		String str1 = str[0];
		
		System.out.println(str1);
		
	}

}
