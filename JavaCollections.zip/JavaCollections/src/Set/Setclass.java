package Set;

import java.util.HashSet;
import java.util.Set;

public class Setclass {
	
	//it wont allow duplicate values
	//display elements in unordered way

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Object> set = new HashSet<Object>();
		
		set.add("String1");
		set.add(1);
		set.add(true);
		set.add(1);//it wont display as it is a duplicate value
		
		System.out.println(set);
		
		set.remove(1);
		System.out.println(set);
		
		System.out.println(set.size());
		
		Set<Object> set2 = new HashSet<Object>();
		set.add("String1");
		set.add(2);
		set.add(false);
		
		System.out.println("Comman values in both the sets "+set.retainAll(set2));
		
		
		
		
		
		
		
		
		
		
		System.out.println(">>>>>>>>>>>>>>>>");
		
		//Simple example of removing duplicate values from a string using set or hashset
		
		/*String str = "Newworkbook";
		
		char ch[] = str.toCharArray();
		
		System.out.println(ch[2]);
		
		HashSet<Object> set3 = new HashSet<Object>();
		
		for(int i=0;i<ch.length;i++) {
			
			set3.add(ch[i]);
		}
		System.out.print(set3);*/
		
	
		
		
	}

}
