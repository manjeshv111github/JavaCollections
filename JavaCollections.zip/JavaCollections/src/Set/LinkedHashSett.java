package Set;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class LinkedHashSett {
	//it prints the values in Ordered way

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
		
		lhs.add(1);
		lhs.add(4);
		lhs.add(2);
		lhs.add(3);
		
		System.out.println(lhs);
		
		//we dont have retrieve method available in Set interface so we need add all those values into ArrayList then use get method
		
		ArrayList<Integer> aarlst = new ArrayList<Integer>();
		
		aarlst.addAll(lhs);
		
		System.out.println(aarlst);
		
		int inf = aarlst.get(2);
		
		System.out.println(inf);

	}

}
