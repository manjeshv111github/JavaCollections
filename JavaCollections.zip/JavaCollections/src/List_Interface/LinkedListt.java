package List_Interface;
import java.util.*;
public class LinkedListt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Object> linkedlst = new LinkedList<Object>(); //here i added data type as Object so that we can add any type of data
		linkedlst.add("String");
		linkedlst.add(1);
		linkedlst.add(1);
		linkedlst.add(true);
		
		System.out.println(linkedlst);
		
		linkedlst.add(1, 4);
		System.out.println(linkedlst);
		
		linkedlst.add(1, "String2");
		System.out.println(linkedlst);
		
		linkedlst.remove(1);
		System.out.println(linkedlst);
		
		System.out.println(linkedlst.get(3));
		
		

	}

}
