package List_Interface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Arralist is resizable
		
		List<String> lst = new ArrayList<String>();
		//adding values
		lst.add("First");
		lst.add("Second");
		lst.add("Second");
		lst.add("Fourth");
		System.out.println(lst);

		
		//adding value at perticular position
		lst.add(2, "Third");
		System.out.println(lst);
		
		//adding all values from one list to another
		List<String> lst2 = new ArrayList<String>();
		lst2.addAll(lst);
		System.out.println(lst2);
		
		//get values from particular position
		lst.get(0);
		lst2.get(0);
		System.out.println(lst.get(0));
		System.out.println(lst2.get(4));
		
		//Remove values from particular position
		lst.remove(2);
		System.out.println(lst);
		
		for(int i=0;i<lst.size();i++) {
			String s=lst.get(i);
			System.out.print(s+" ");
		}
		
		System.out.println(">>>>>>>>>>>>");
		
		//sample programme to sort values in a acceding order
		
		//get the values from array
		int int1[]= {4,2,6,5,8,1,2,2};
		
		ArrayList<Integer> aar1 = new ArrayList<Integer>();
		
		for(int t=0;t<int1.length;t++) {
			aar1.add(int1[t]);
		}
		System.out.println(aar1);
		Collections.sort(aar1);  //display in acceding order
		System.out.println(aar1);
		Collections.sort(aar1,Collections.reverseOrder());//reversing the order
		System.out.println(aar1);
		System.out.println(Collections.frequency(aar1, 2)); // counting number of times duplicate values present
		System.out.println(Collections.min(aar1));//Min value
		System.out.println(Collections.max(aar1));//Max value
		
		//converting arralist to array
		
		ArrayList<String> ar = new ArrayList<String>();
		
		ar.add("111");
		ar.add("222");
		ar.add("333");
		ar.add("444");
		
		System.out.println(ar);
		
		String[] str = ar.toArray(new String[0]);
		
		for(String str1:str) {
			System.out.println(str1);
		}
		
		System.out.println(str[1]);

	}

}
